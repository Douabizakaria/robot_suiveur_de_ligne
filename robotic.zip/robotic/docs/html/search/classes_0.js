var searchData=
[
  ['linedetect',['LineDetect',['../classLineDetect.html',1,'']]]
];

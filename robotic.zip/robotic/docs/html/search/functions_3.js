var searchData=
[
  ['gauss',['Gauss',['../classLineDetect.html#a95f915b8096799a874d5cec002f3dca3',1,'LineDetect::Gauss()'],['../test__detect_8cpp.html#ae47c8c035bbf706e10084b39bcf91eeb',1,'gauss():&#160;test_detect.cpp']]]
];

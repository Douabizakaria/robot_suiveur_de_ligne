var searchData=
[
  ['stop',['stop',['../test__detect_8cpp.html#ae51416af540512a3ba419ad44754360e',1,'test_detect.cpp']]]
];
